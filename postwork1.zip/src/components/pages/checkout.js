import MainCarousel from "../Styles/MainCarousel";

function Checkout(){
    return(
         <MainCarousel />
    )
}

export default Checkout;