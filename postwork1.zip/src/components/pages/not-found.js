function NotFound(){
    return(
    <div className="card">
        <div className="card-body">
         <h1 className="text-center">404 PAGE NOT FOUND</h1>
         <p className="text-center">return into the home page</p>
         </div>
    </div> 
    )
}

export default NotFound;