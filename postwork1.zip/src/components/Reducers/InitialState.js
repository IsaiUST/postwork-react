const initialState = {
	cart: [],
};

export default initialState;